package com.mycompany.poe_part_2_st10443406;
import javax.swing.*;   
import java.util.ArrayList;
/**
 * The Array class manages tasks, including their developers, names, statuses, and durations.
 * It provides methods for interacting with task data, such as displaying tasks, searching, and deletion.
 */

public class Array {
    final private ArrayList<String> developers; // List to store developer names
    final private ArrayList<String> taskNames;  // List to store task names
    final private ArrayList<String> taskStatus; // List to store task statuses(e.g. "Done", "To Do" etc)
    final private ArrayList<Integer> taskDurations; // List to store task durations in hours
      
    public Array() {
     /**
     * Constructor to initialize the Array object.
     * Sets up the ArrayLists to store task information.
     */
        developers = new ArrayList<>();
        taskNames = new ArrayList<> ();
        taskStatus = new ArrayList<>();
        taskDurations = new ArrayList<>();        
     }
          
     public void displayDoneTasks() {
     /**
     * Displays all tasks that have the status "Done."
     * Lists the developer, task name, and task duration for each "Done" task.
     */
         StringBuilder doneTasks = new StringBuilder();
         // Initializes a StringBuilder object to efficiently construct and store the result string.
        // StringBuilder is used here instead of regular string concatenation because it is more memory-efficient
       // and faster when handling multiple string manipulations in a loop or iterative process.
         doneTasks.append("Tasks with status Done:\n");
         
         //Iterate through tasks to find those with the status "Done" using a for loop
         for(int i = 0; i< taskNames.size(); i++) {
             if(taskStatus.get(i).equals("Done")){
                 doneTasks.append("Developer").append(developers.get(i)).append(",");
                 doneTasks.append("Task Name").append(taskNames.get(i)).append(",");
                 doneTasks.append("Task Duration").append(taskDurations.get(i)).append(";");
             }
         }
         //Display the results of the search 
         JOptionPane.showMessageDialog(null, doneTasks.toString());                       
     }
     
    public void displayLongestTask(){
        /*
         Displays the task with the longest duration, including the developer and task name.
        */
        int maxDuration = 0; //Stores the maximum duration found
        int maxIndex = -1;       //Stores the index of the task with the longest duration
        //Use a for-loop to iterate through the task durations to find the maximum
        for(int i = 0; i< taskDurations.size(); i++){
            if(taskDurations.get(i) > maxDuration){
                maxDuration = taskDurations.get(i);
                maxIndex = i;
            }
        }
        //Display the task with the longest duration along with the developer assigned to the task
        JOptionPane.showMessageDialog(null, "task withe the longest duration\nDeveloper " + developers + " \nduration " + taskDurations.get(maxIndex));
    }
    /**
      Searches for a task by its name and displays the task details if found.     
      @param name The name of the task to search for.
     */
     public String searchTaskByName(String name){
         // Initializes a StringBuilder object to efficiently construct and store the result string.
        // StringBuilder is used here instead of regular string concatenation because it is more memory-efficient
       // and faster when handling multiple string manipulations in a loop or iterative process.
         StringBuilder result = new StringBuilder();
         //Search for the task with the specified name
         for(int i =0; i < taskNames.size(); i++) {
             if(taskNames.get(i).equals(name)){
                 //displays the task name, duration and name of the developer if it is found
                 result.append("Developer: ").append(developers.get(i)).append(",");
                 result.append("Task Name: ").append(taskNames.get(i)).append(",");
                 result.append("Task Duration: ").append(taskDurations.get(i)).append(";");                                  
             }
         }// Generates a messsage displaying the task name, duration and developer
         JOptionPane.showMessageDialog(null, result.toString());
         return null; //Task not found
     }
     
      /**
     * Searches for all tasks assigned to a specific developer and displays their details.
     *
     * @param developer The name of the developer to search for.
     */
     public String searchTasksByDeveloper(String developer){
         // Initializes a StringBuilder object to efficiently construct and store the result string.
        // StringBuilder is used here instead of regular string concatenation because it is more memory-efficient
       // and faster when handling multiple string manipulations in a loop or iterative process.         
         StringBuilder result = new StringBuilder();
         //Using a for-loop to iterate through the tasks assigned to the specified developer
         for(int i = 0 ; i < developers.size(); i++){
             if(developers.get(i).contains(developer)){
                 //append their task name and their status
                 result.append("Task Name: ").append(taskNames.get(i)).append(";");
                 result.append("Task Status: ").append(taskStatus.get(i)).append(";");
             }
         }//Generate a message giving the user the task name and status of the specified developer
         JOptionPane.showMessageDialog(null, result.toString());
         return null;
     }
         /**
     * Deletes a task by its name and removes its details from all lists.
     *
     * @param taskName The name of the task to delete.
     */
     public boolean deleteTaskByTaskName(String taskName){
         //set the boolean of taskFound variable to false
         boolean taskFound = false;
         //Use a for-loop to iterate through the recorded tasks for the task with the name given by the user
         for(int i = 0; i  < taskNames.size(); i++) {
             if(taskNames.get(i).equals(taskName)){
                 /*
                 -Use the remove() method on all relevant ArrayLists to delete the task details, the developer assigned to the task,
                 the task staus and the task duration at the same index.
                 -Set taskFound to true and display a success message using JOptionPane.
                 -Break the loop to stop further iteration.
                 */
                 developers.remove(i);
                 taskNames.remove(i);
                 taskStatus.remove(i);
                 taskDurations.remove(i);
                 taskFound = true;
                 //Send a message that the task was deleted
                 JOptionPane.showMessageDialog(null, "Task: " + taskName + " has been sucessfully deleted!");
                 break;
             }
         }//Simple error handling if the task is not found
         //if the task was not found, display an appropriate message
         if(!taskFound){
             JOptionPane.showMessageDialog(null, "Task: " + taskName + "not found!");
         }
         return false;
     }
      /**
     * Displays the full details of all captured tasks, including developers, names, statuses, and durations.
     */
     public String displayAllTasks(){

         // Initializes a StringBuilder object to efficiently construct and store the result string.
        // StringBuilder is used here instead of regular string concatenation because it is more memory-efficient
       // and faster when handling multiple string manipulations in a loop or iterative process.         
         StringBuilder allTasks = new StringBuilder();
         allTasks.append("Full details of ALL captured tasks:\n\n");
         //Use a for-loop to iterate through all the tassk and collect their details to display them to the user
       for (int i = 0; i < taskNames.size(); i++) {
           //append all the details of the various arrays: Task, developer, task Name, task Status and task duration 
           allTasks.append("Task ").append(i+1).append(":\n");
           allTasks.append("Developer ").append(developers.get(i)).append(":\n");
           allTasks.append("Task Name ").append(taskNames.get(i)).append(":\n");
           allTasks.append("Task Status ").append(taskStatus.get(i)).append(":\n");
           allTasks.append("Task Duration ").append(taskDurations.get(i)).append(" hours\n");
           allTasks.append("----------------------\n");
    }
       JOptionPane.showMessageDialog(null, allTasks.toString());
         if(taskNames.isEmpty()) {
             //Cater to the possibility that no tasks have been captured yet. Useful in case of testing and debugging
             JOptionPane.showMessageDialog(null, "No tasks have been captured yet! ");
             return null;             
         }       
         return null;
     }

    void addTask(String mike_Smith, String create_Login, int i, String to_Do) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

//    void addTask(String mike_Smith, String create_Login, int i, String to_Do) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
//    }
//
//    void addTask(String glenda_Oberholzer, String add_Arrays, int i, String to_Do) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
//    }

    ArrayList<String> getDevelopers() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    String getLongestTask() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}