///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
// */
package com.mycompany.poe_part_2_st10443406;

import java.util.ArrayList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Array class.
 * This test file ensures the functionality of task management in the Array class.
 * It validates proper data handling and expected outputs for the given requirements.
 */
public class ArrayTest {

    /**
     * Test to ensure the developer array is correctly populated with expected data.
     * This test checks that each developer's name corresponds to the correct test data for tasks 1-4.
     */
    @Test
    public void testDeveloperArrayCorrectlyPopulated() {
        // Arrange
        Array taskArray = new Array();
        populateTestData(taskArray);

        // Act
        ArrayList<String> developers = taskArray.getDevelopers();

        // Assert
        assertEquals("Mike Smith", developers.get(0));
        assertEquals("Edward Harrison", developers.get(1));
        assertEquals("Samantha Paulson", developers.get(2));
        assertEquals("Glenda Oberholzer", developers.get(3));
    }

    /**
     * Test to verify the method that identifies the task with the longest duration.
     * This test ensures that the correct developer and task duration are returned.
     */
    @Test
    public void testDisplayLongestTask() {
        // Arrange
        Array taskArray = new Array();
        populateTestData(taskArray);

        // Act
        String longestTaskDeveloper = taskArray.getLongestTask();

        // Assert
        assertEquals("Glenda Oberholzer, 11", longestTaskDeveloper);
    }

    /**
     * Test to check if a task can be searched by its name.
     * This test ensures that the developer and task name are correctly retrieved.
     */
    @Test
    public String testSearchTaskByName() {
        // Arrange
        Array taskArray = new Array();
        populateTestData(taskArray);

        // Act
        String taskDetails = taskArray.searchTaskByName("Create Login");

        // Assert
        assertEquals("Developer: Mike Smith, Task Name: Create Login", taskDetails);
        
        return taskDetails;
    }

    /**
     * Test to ensure that tasks assigned to a specific developer can be searched.
     * This test checks that only the relevant task name is returned.
     */
    @Test
    public void testSearchTasksByDeveloper() {
        // Arrange
        Array taskArray = new Array();
        populateTestData(taskArray);

        // Act
        String developerTasks = taskArray.searchTasksByDeveloper("Samantha Paulson");

        // Assert
        assertEquals("Create Reports", developerTasks);
    }

    /**
     * Test to validate that a task can be successfully deleted by its name.
     * This test also ensures that the deleted task is no longer searchable.
     */
    @Test
    public void testDeleteTaskByTaskName() {
        // Arrange
        Array taskArray = new Array();
        populateTestData(taskArray);

        // Act
        boolean isDeleted = taskArray.deleteTaskByTaskName("Create Reports");

        // Assert
        assertTrue(isDeleted);

        // Verify the task is no longer searchable
        String taskDetails = taskArray.searchTaskByName("Create Reports");
        assertNull(taskDetails);
    }

    /**
     * Test to ensure that all captured tasks are displayed correctly.
     * This test checks the full details of all tasks against the expected format.
     */
    @Test
    public void testDisplayAllTasks() {
        // Arrange
        Array taskArray = new Array();
        populateTestData(taskArray);

        // Act
        String allTasks = taskArray.displayAllTasks();

        // Assert
        String expectedOutput = """
            Full details of ALL captured tasks:

            Task 1:
            Developer: Mike Smith
            Task Name: Create Login
            Task Status: To Do
            Task Duration: 5 hours
            ----------------------

            Task 2:
            Developer: Edward Harrison
            Task Name: Create Add Features
            Task Status: Doing
            Task Duration: 5 hours
            ----------------------

            Task 3:
            Developer: Samantha Paulson
            Task Name: Create Reports
            Task Status: Done
            Task Duration: 2 hours
            ----------------------

            Task 4:
            Developer: Glenda Oberholzer
            Task Name: Add Arrays
            Task Status: To Do
            Task Duration: 11 hours
            ----------------------
            """;

        assertEquals(expectedOutput.trim(), allTasks.trim());
    }

    /**
     * Helper method to populate the Array class with test data.
     * This method ensures consistency in the test data used across all tests.
     *
     * @param taskArray The Array object to populate with test data.
     */
    private void populateTestData(Array taskArray) {
        taskArray.addTask("Mike Smith", "Create Login", 5, "To Do");
        taskArray.addTask("Edward Harrison", "Create Add Features", 5, "Doing");
        taskArray.addTask("Samantha Paulson", "Create Reports", 2, "Done");
        taskArray.addTask("Glenda Oberholzer", "Add Arrays", 11, "To Do");
    }
}
