## Reference List ## 

1) GeeksforGeeks. (2016). Regular Expressions in Java. [online] Available at: https://www.geeksforgeeks.org/regular-expressions-in-java/.

2) OpenAI. (2024). ChatGPT conversation. Available at: https://chatgpt.com/c/f0984af3-60d6-4cf0-9d44-7e0c7cfd5239 (Accessed: 30 August 2024).

3) www.javatpoint.com. (n.d.). Java Regex | Regular Expression - javatpoint. [online] Available at: https://www.javatpoint.com/java-regex.

4) www.w3schools.com. (n.d.). Java Regular Expressions. [online] Available at: https://www.w3schools.com/java/java_regex.asp.